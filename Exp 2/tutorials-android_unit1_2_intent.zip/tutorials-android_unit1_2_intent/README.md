# android_unit1_2

### What is this example: 

A "counter" example for toying with `intent` (switch between activities)

### version tested
|Android Studio            | Android SDK | Gradle | Emulator |
|--------------------------|-------------|--------|----------|
|Giraffe 2022.3.1 Patch 2  |33           | 8.0.0  | Pixel 3a |
