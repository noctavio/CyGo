# android_unit1_1

### What is this example: 

A "hello world" example for testing environment setup

### version tested
|Android Studio            | Android SDK | Gradle | Emulator |
|--------------------------|-------------|--------|----------|
|Giraffe 2022.3.1 Patch 2  |33           | 8.0.0  | Pixel 3a |
