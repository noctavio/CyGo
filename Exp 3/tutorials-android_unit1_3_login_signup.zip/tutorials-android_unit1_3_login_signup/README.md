# android_unit1_3

### What is this example: 

A "login & signup" example. This is only an example of the interface, NO actual connections are made in this example.

### version tested
|Android Studio            | Android SDK | Gradle | Emulator |
|--------------------------|-------------|--------|----------|
|Giraffe 2022.3.1 Patch 2  |33           | 8.0.0  | Pixel 3a |
